Kakeibo — press stuff
=====================

Hi, I'm Pablo, and I made a very, very small budgeting app based on the
Japanese kakeibo method. It's about writing down the money that comes in and
goes out each month, tracking every expense by hand, and reflecting on
everything that happened at the end of the month. Its natural habitat is a
notebook, but this app lives in your pocket.

I'm very tired of subscriptions, free trials, ads, AI everywhere for no
reason... So this app goes against all of that: one-time purchase
(€2.99–€3.99), no ads, no cookies, no LLMs, not even a server involved.
Everything stays on your phone.

The basics
----------
App: Kakeibo: a budgeting app for spending more consciously
Platforms: iOS and Android
Price: one-time purchase (€2.99–€3.99); no subscription, ads, tracking or AI
Languages: English, Spanish and Italian
In the stores since: April 2026
Made in: Barcelona
Website: https://getkakeibo.com
Press page: https://getkakeibo.com/en/press/

Short description
-----------------
Kakeibo is a very small offline budgeting app based on the Japanese kakeibo
method. It's available on iOS and Android for a one-time purchase, with no
subscriptions, ads, accounts, cookies, AI or bank connections. It's built and
maintained by one person in Barcelona.

Want to try it?
---------------
Email hola@getkakeibo.com and I'll be happy to send you a code so you can
download it for free.

Files
-----
- kakeibo-icon.png (1000x1000)
- ogimage.png (1200x630)
- screenshots/en/ and screenshots/es/ (PNG)

Use the screenshots and icon for anything related to Kakeibo. Just don't edit
them or make it look like I endorsed something I didn't.
